﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftUniStoreApp.BindingModels
{
    public class DeleteGameBindingModel
    {
        public string Title { get; set; }
    }
}
